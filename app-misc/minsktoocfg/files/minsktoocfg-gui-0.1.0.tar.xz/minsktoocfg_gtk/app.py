import os, subprocess, sys
from pathlib import Path
import gi
from minsktoocfg.cli import CfgStore, INFO_LINES
from minsktoocfg.portage_io import ENV_PROFILES_DIR, ensure_gentoo_os

def _launch_gtk(ver: str) -> None:
    try: ensure_gentoo_os()
    except RuntimeError as exc: print(f"ERROR: {exc}", file=sys.stderr); sys.exit(1)
    gi.require_version("Gtk", ver)
    from gi.repository import Gtk, Pango
    IS_GTK4 = (ver == "4.0")

    def _box(orient, sp=4): return Gtk.Box(orientation=orient, spacing=sp)
    def _append(box, child, expand=False):
        if IS_GTK4:
            if expand:
                child.set_hexpand(True)
                if box.get_orientation() == Gtk.Orientation.VERTICAL: child.set_vexpand(True)
            box.append(child)
        else: box.pack_start(child, expand, expand, 0)
    def _clear(box):
        if IS_GTK4:
            while (c := box.get_first_child()): box.remove(c)
        else:
            for c in box.get_children(): box.remove(c)

    def _scroll(child):
        sc = Gtk.ScrolledWindow()
        if IS_GTK4:
            sc.set_min_content_width(20); sc.set_min_content_height(36); sc.set_child(child)
        else:
            sc.add(child)
        return sc

    class minsktooGtkWindow(Gtk.Window):
        def __init__(self) -> None:
            super().__init__(title=f"minsktoo Portage Configurator (GTK{ver.__getitem__(0)})")
            self.set_default_size(1180, 760)
            self.store = CfgStore(); self.cur_pkg = None; self.active_env = ""
            root = _box(Gtk.Orientation.VERTICAL, 6); root.set_margin_top(6); root.set_margin_bottom(6); root.set_margin_start(6); root.set_margin_end(6)
            self.set_child(root) if IS_GTK4 else self.add(root)
            paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL); paned.set_position(340); (paned.set_shrink_start_child(True), paned.set_shrink_end_child(True)) if IS_GTK4 else None; _append(root, paned, True)
            left = _box(Gtk.Orientation.VERTICAL, 4)
            self.search = Gtk.Entry(); self.search.set_width_chars(8); self.search.set_placeholder_text("Filter packages...")
            self.search.connect("changed", lambda *_: self.refresh_tree()); _append(left, self.search)
            self.slow_chk = Gtk.CheckButton(label="Sort by slowest build time"); (self.slow_chk.get_child().set_ellipsize(Pango.EllipsizeMode.END) if self.slow_chk.get_child() else None)
            self.slow_chk.connect("toggled", lambda *_: self.refresh_tree()); _append(left, self.slow_chk)
            self.tstore = Gtk.TreeStore(str, str, str)
            self.tview = Gtk.TreeView(model=self.tstore)
            for i, col_t in enumerate(("Package", "Info")):
                cr = Gtk.CellRendererText(); cr.set_property("ellipsize", Pango.EllipsizeMode.END); col = Gtk.TreeViewColumn(col_t, cr, text=i); col.set_resizable(True); col.set_min_width(40); col.set_expand(i == 0); self.tview.append_column(col)
            self.tview.get_selection().connect("changed", self.on_tree_sel)
            sc = _scroll(self.tview); _append(left, sc, True)
            leg = Gtk.Label(label="Badges: USE | ENV | KW | MASK | UNMASK | PATCH"); leg.set_xalign(0.0); leg.set_ellipsize(Pango.EllipsizeMode.END); _append(left, leg)
            paned.set_start_child(left) if IS_GTK4 else paned.pack1(left, False, False)
            right = _box(Gtk.Orientation.VERTICAL, 4)
            self.hdr = Gtk.Label(label="Select a package on the left."); self.hdr.set_xalign(0.0); self.hdr.set_ellipsize(Pango.EllipsizeMode.END); _append(right, self.hdr)
            self.nb = Gtk.Notebook(); self.nb.set_scrollable(True); _append(right, self.nb, True)

            t_use = _box(Gtk.Orientation.VERTICAL, 6); t_use.set_margin_top(6); t_use.set_margin_bottom(6); t_use.set_margin_start(6); t_use.set_margin_end(6); u_bar = _box(Gtk.Orientation.HORIZONTAL, 4)
            self.u_fltr = Gtk.Entry(); self.u_fltr.set_width_chars(8); self.u_fltr.set_placeholder_text("Filter USE flags...")
            self.u_fltr.connect("changed", lambda *_: self.rebuild_use()); _append(u_bar, self.u_fltr, True)
            b_ref = Gtk.Button(label="Refresh"); b_ref.connect("clicked", lambda *_: self.reload_all()); _append(u_bar, b_ref)
            _append(t_use, u_bar)
            self.u_box = _box(Gtk.Orientation.VERTICAL, 2); u_sc = _scroll(self.u_box); _append(t_use, u_sc, True)
            self.nb.append_page(t_use, Gtk.Label(label="USE"))

            t_env = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL); t_env.set_position(240); (t_env.set_shrink_start_child(True), t_env.set_shrink_end_child(True)) if IS_GTK4 else None
            el_wrap = _box(Gtk.Orientation.VERTICAL, 4); el_wrap.set_margin_top(6); el_wrap.set_margin_start(6); el_wrap.set_margin_end(6)
            el_hdr = Gtk.Label(label="Assign /etc/portage/env profiles:"); el_hdr.set_xalign(0.0); _append(el_wrap, el_hdr)
            self.e_box = _box(Gtk.Orientation.VERTICAL, 2); e_sc = _scroll(self.e_box); _append(el_wrap, e_sc, True)
            t_env.set_start_child(el_wrap) if IS_GTK4 else t_env.pack1(el_wrap, False, False)
            ed_r = _box(Gtk.Orientation.VERTICAL, 6); ed_r.set_margin_top(6); ed_r.set_margin_start(6); ed_r.set_margin_end(6); ed_r.set_margin_bottom(6); ed_top = _box(Gtk.Orientation.HORIZONTAL, 4)
            self.e_name = Gtk.Entry(); self.e_name.set_width_chars(8); self.e_name.set_placeholder_text("profile.conf..."); _append(ed_top, self.e_name, True)
            for lbl, fn in (("+", self.new_env), ("Save", self.save_env), ("Delete", self.del_env)):
                b = Gtk.Button(label=lbl); b.connect("clicked", lambda *_, f=fn: f()); _append(ed_top, b)
            _append(ed_r, ed_top)
            self.e_buf = Gtk.TextBuffer(); tv = Gtk.TextView(buffer=self.e_buf); tv.set_monospace(True)
            tv_sc = _scroll(tv); _append(ed_r, tv_sc, True)
            t_env.set_end_child(ed_r) if IS_GTK4 else t_env.pack2(ed_r, True, False)
            self.nb.append_page(t_env, Gtk.Label(label="Environment"))

            self.k_box = _box(Gtk.Orientation.VERTICAL, 4); self.k_box.set_margin_top(6); self.k_box.set_margin_bottom(6); self.k_box.set_margin_start(6); self.k_box.set_margin_end(6); k_sc = _scroll(self.k_box)
            self.nb.append_page(k_sc, Gtk.Label(label="Keywords"))
            self.p_box = _box(Gtk.Orientation.VERTICAL, 4); self.p_box.set_margin_top(6); self.p_box.set_margin_bottom(6); self.p_box.set_margin_start(6); self.p_box.set_margin_end(6); p_sc = _scroll(self.p_box)
            self.nb.append_page(p_sc, Gtk.Label(label="Patches"))
            ib = Gtk.TextBuffer(); ib.set_text("\n".join(INFO_LINES)); itv = Gtk.TextView(buffer=ib); itv.set_editable(False); itv.set_monospace(True)
            isc = _scroll(itv); self.nb.append_page(isc, Gtk.Label(label="Info"))

            paned.set_end_child(right) if IS_GTK4 else paned.pack2(right, True, False)
            self.stk_buf = Gtk.TextBuffer(); self.stk_buf.set_text("Active USE Stack: (none)")
            stk_tv = Gtk.TextView(buffer=self.stk_buf); stk_tv.set_editable(False); stk_tv.set_monospace(True); stk_tv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
            stk_sc = _scroll(stk_tv); stk_sc.set_size_request(-1, 68); _append(root, stk_sc)
            bot = _box(Gtk.Orientation.HORIZONTAL, 4); _append(bot, Gtk.Label(label=""), True)
            b_save = Gtk.Button(label="Save"); b_save.set_size_request(96, -1); b_save.connect("clicked", lambda *_: self.on_save()); _append(bot, b_save)
            _append(root, bot); self.refresh_tree()

        def _env_dir(self) -> Path:
            return ENV_PROFILES_DIR if os.geteuid() == 0 else (Path.cwd() / "portage-preview" / "env")

        def _msg(self, title: str, body: str, ask: bool = False) -> bool:
            dlg = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION if ask else Gtk.MessageType.INFO, buttons=Gtk.ButtonsType.YES_NO if ask else Gtk.ButtonsType.OK, text=title)
            dlg.format_secondary_text(body)
            if IS_GTK4:
                res = {"v": False}
                dlg.connect("response", lambda d, r: (res.update({"v": r == Gtk.ResponseType.YES}), d.destroy()))
                dlg.present()
                while dlg.get_visible(): gi.repository.GLib.MainContext.default().iteration(True)
                return res.get("v")
            r = dlg.run(); dlg.destroy(); return r == Gtk.ResponseType.YES

        def refresh_tree(self) -> None:
            q = self.search.get_text().strip().lower(); self.tstore.clear(); pkgs = self.store.state.get("packages", ())
            def _bd(p):
                b = ([p.get("build_fmt")] if p.get("build_secs", 0) > 0 else []) + (["USE"] if p.get("use_mod") else []) + (["ENV"] if p.get("cur_envs") else []) + (["KW"] if any(p.get("cur_kw", {}).values()) else []) + (["MASK"] if p.get("cur_mask") != "NONE" else []) + (["UNMASK"] if p.get("cur_unmask", "NONE") != "NONE" else []) + (["PATCH"] if p.get("has_patch") else [])
                return " | ".join(b)
            if self.slow_chk.get_active():
                slow = sorted((x for x in pkgs if x.get("build_secs", 0) > 0), key=lambda x: (-x.get("build_secs", 0), x.get("cp")))
                if slow:
                    top = self.tstore.append(None, (f"Top Slowest ({len(slow)})", "genlop -t", ""))
                    for p in slow:
                        bd = _bd(p)
                        if not q or q in f"{p.get('cp')} {bd}".lower(): self.tstore.append(top, (p.get("name"), bd, p.get("cp")))
            by_cat = {}
            for p in pkgs: by_cat.setdefault(p.get("cat"), []).append(p)
            for cat in sorted(by_cat):
                ms = [p for p in by_cat.get(cat, ()) if not q or q in f"{p.get('cp')} {_bd(p)}".lower()]
                if not ms: continue
                par = self.tstore.append(None, (f"{cat} ({len(ms)})", "", ""))
                for p in ms: self.tstore.append(par, (p.get("name"), _bd(p), p.get("cp")))
            if q or self.slow_chk.get_active(): self.tview.expand_all()

        def on_tree_sel(self, sel) -> None:
            m, it = sel.get_selected()
            if not it or not m.get_value(it, 2): return
            self.cur_pkg = self.store.pkg_map.get(m.get_value(it, 2))
            if not self.cur_pkg: return
            self.hdr.set_text(f"{self.cur_pkg.get('cpv')}   |   Last merge: {self.cur_pkg.get('build_fmt')}")
            self.stk_buf.set_text(f"Active USE Stack: {self.cur_pkg.get('use_stack')}")
            self.rebuild_use(); self.rebuild_env(); self.rebuild_kw(); self.rebuild_pat()

        def reload_all(self) -> None:
            cp = self.cur_pkg.get("cp") if self.cur_pkg else None
            self.store = CfgStore(); self.refresh_tree()
            if cp and cp in self.store.pkg_map:
                self.cur_pkg = self.store.pkg_map.get(cp)
                self.rebuild_use(); self.rebuild_env(); self.rebuild_kw(); self.rebuild_pat()

        def rebuild_use(self) -> None:
            _clear(self.u_box); p = self.cur_pkg
            if not p: return
            qf = self.u_fltr.get_text().strip().lower()
            for f in p.get("flags", ()):
                fl = f.get("flag")
                if qf and qf not in fl.lower(): continue
                cb = Gtk.CheckButton(label=f"{fl} *" if f.get("forced") else fl)
                cb.set_active(bool(p.get("cur_flags", {}).get(fl)))
                cb.connect("toggled", self._on_use, fl, f, p); _append(self.u_box, cb)
            if not IS_GTK4: self.u_box.show_all()

        def _on_use(self, cb, fl: str, meta: dict, p: dict) -> None:
            st = cb.get_active()
            if meta.get("forced") and st != bool(p.get("cur_flags", {}).get(fl)):
                if not self._msg("Profile-Locked USE Flag", f"'{fl}' is {meta.get('force_reason')}.\nApply override anyway?", True):
                    cb.set_active(not st); return
            p.get("cur_flags").update({fl: st})

        def rebuild_env(self) -> None:
            _clear(self.e_box); p = self.cur_pkg
            if not p: return
            for e in p.get("envs", ()):
                en = e.get("name"); row = _box(Gtk.Orientation.HORIZONTAL, 4)
                cb = Gtk.CheckButton(); cb.set_active(en in p.get("cur_envs", set()))
                cb.connect("toggled", lambda w, n=en, pkg=p: (pkg.get("cur_envs").add(n) if w.get_active() else pkg.get("cur_envs").discard(n)))
                btn = Gtk.Button(label=en); btn.set_has_frame(False) if IS_GTK4 else btn.set_relief(Gtk.ReliefStyle.NONE)
                (btn.get_child().set_xalign(0.0) if btn.get_child() else None)
                btn.connect("clicked", lambda *_, n=en: self.load_env(n))
                _append(row, cb); _append(row, btn, True); _append(self.e_box, row)
            if not IS_GTK4: self.e_box.show_all()

        def load_env(self, fn: str) -> None:
            self.active_env = fn; self.e_name.set_text(fn)
            lf = self._env_dir() / fn; sf = ENV_PROFILES_DIR / fn
            t = lf if lf.is_file() else sf
            self.e_buf.set_text(t.read_text(encoding="utf-8", errors="ignore") if t.is_file() else "")

        def new_env(self) -> None:
            self.active_env = ""; self.e_name.set_text("custom.conf")
            self.e_buf.set_text('MAKEOPTS="-j8 -l8"\nNINJAFLAGS="-j8 -l8"\nCARGO_BUILD_JOBS="8"\n')

        def save_env(self) -> None:
            raw = self.e_name.get_text().strip()
            if not raw: return
            fn = Path(raw if raw.endswith(".conf") else f"{raw}.conf").name
            d = self._env_dir(); d.mkdir(parents=True, exist_ok=True)
            if self.active_env and self.active_env != fn: (d / self.active_env).unlink(missing_ok=True)
            s_it, e_it = self.e_buf.get_bounds()
            body = self.e_buf.get_text(s_it, e_it, True)
            (d / fn).write_text(body if body.endswith(chr(10)) else (body + chr(10)), encoding="utf-8")
            self.active_env = fn; self.e_name.set_text(fn); self.reload_all()

        def del_env(self) -> None:
            if self.active_env: (self._env_dir() / self.active_env).unlink(missing_ok=True); self.active_env = ""; self.e_name.set_text(""); self.e_buf.set_text(""); self.reload_all()

        def rebuild_kw(self) -> None:
            _clear(self.k_box); p = self.cur_pkg
            if not p: return
            for kw in ("amd64", "~amd64", "**"):
                cb = Gtk.CheckButton(label=f"Accept {kw}"); cb.set_active(bool(p.get("cur_kw", {}).get(kw)))
                cb.connect("toggled", lambda w, k=kw, pkg=p: pkg.get("cur_kw").update({k: w.get_active()})); _append(self.k_box, cb)
            for key, title, opts in (("cur_kw_mode", "Keyword Scope", (("ALL", "All versions"), ("EQ", "Exact version"), ("FWD", "Forward upgrades"))), ("cur_mask", "Package Mask", (("NONE", "Unmasked"), ("ALL", "Mask all"), ("EQ", "Mask exact"), ("FWD", "Mask forward"))), ("cur_unmask", "Package Unmask", (("NONE", "No local unmask"), ("ALL", "Unmask all"), ("EQ", "Unmask exact"), ("FWD", "Unmask forward")))):
                _append(self.k_box, Gtk.Label(label=f"\n{title}:")); grp = None
                for m, lbl in opts:
                    rb = Gtk.CheckButton(label=lbl) if IS_GTK4 else Gtk.RadioButton.new_with_label_from_widget(grp, lbl)
                    if IS_GTK4 and grp: rb.set_group(grp)
                    if not grp: grp = rb
                    rb.set_active(p.get(key) == m)
                    rb.connect("toggled", lambda w, mod=m, k=key, pkg=p: pkg.update({k: mod}) if w.get_active() else None); _append(self.k_box, rb)
            if not IS_GTK4: self.k_box.show_all()

        def rebuild_pat(self) -> None:
            _clear(self.p_box); p = self.cur_pkg
            if not p: return
            for pt in p.get("patches", ()):
                cb = Gtk.CheckButton(label=f"Enable patch: {pt.get('base_name')}"); cb.set_active(bool(pt.get("cur_en")))
                cb.connect("toggled", lambda w, item=pt: item.update({"cur_en": w.get_active()})); _append(self.p_box, cb)
            if not IS_GTK4: self.p_box.show_all()

        def on_save(self) -> None:
            chg, wrn = self.store.build_sanity_report()
            if not chg: self._msg("No Changes", "No pending changes to save."); return
            rep = ("\n".join(wrn) + "\n\n" if wrn else "") + "\n".join(chg)
            if not self._msg("Pre-Save Sanity Check", rep, True): return
            n = self.store.save_all(); self.reload_all()
            if os.geteuid() == 0 and self._msg("Launch Emerge", f"Saved {n} change(s).\nOpen Konsole and run 'emerge -auDN @world' now?", True):
                subprocess.Popen(("konsole", "--hold", "-e", "emerge", "-auDN", "@world"))

    if IS_GTK4:
        prov = Gtk.CssProvider(); prov.load_from_data(b"scrollbar slider { min-width: 6px; min-height: 6px; }")
        Gtk.StyleContext.add_provider_for_display(gi.repository.Gdk.Display.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    win = minsktooGtkWindow()
    if IS_GTK4:
        app = Gtk.Application(application_id="org.minsktoo.minsktoocfg.gtk4")
        app.connect("activate", lambda *_: (win.set_application(app), win.present()))
        app.run(None)
    else:
        win.connect("destroy", Gtk.main_quit); win.show_all(); Gtk.main()

def main_gtk3() -> None: _launch_gtk("3.0")
def main_gtk4() -> None: _launch_gtk("4.0")
