import curses, os, subprocess, sys
from pathlib import Path
from minsktoocfg.portage_io import ENV_PROFILES_DIR, PORTAGE_DIR, collect_portage_state, ensure_gentoo_os

THEMES = {
    "modarin": (curses.COLOR_WHITE, curses.COLOR_BLACK, curses.COLOR_WHITE, curses.COLOR_MAGENTA, curses.COLOR_CYAN, curses.COLOR_BLACK, curses.COLOR_YELLOW, curses.COLOR_BLACK),
    "default": (curses.COLOR_WHITE, curses.COLOR_BLUE, curses.COLOR_BLACK, curses.COLOR_CYAN, curses.COLOR_YELLOW, curses.COLOR_BLUE, curses.COLOR_RED, curses.COLOR_WHITE),
    "dark": (curses.COLOR_WHITE, curses.COLOR_BLACK, curses.COLOR_BLACK, curses.COLOR_CYAN, curses.COLOR_GREEN, curses.COLOR_BLACK, curses.COLOR_RED, curses.COLOR_BLACK),
    "gotar": (curses.COLOR_GREEN, curses.COLOR_BLACK, curses.COLOR_BLACK, curses.COLOR_GREEN, curses.COLOR_YELLOW, curses.COLOR_BLACK, curses.COLOR_RED, curses.COLOR_BLACK),
    "nicedark": (curses.COLOR_CYAN, curses.COLOR_BLACK, curses.COLOR_BLACK, curses.COLOR_WHITE, curses.COLOR_YELLOW, curses.COLOR_BLACK, curses.COLOR_RED, curses.COLOR_BLACK),
}
THEME_NAMES = tuple(THEMES.keys())

TABS = ("USE", "Environment", "Keywords", "Patches", "Info")
INFO_LINES = (
    "=== BADGE LEGEND ===",
    "USE = package.use | ENV = package.env | KW = accept_keywords | MASK = mask | UNMASK = unmask | PATCH = patches",
    "",
    "=== PER-PACKAGE PORTAGE QUICK REFERENCE ===",
    "1. package.use: lto, pgo, custom-cflags, system-llvm, threads, zstd (* = profile-locked use.force/use.mask)",
    "2. package.env: MAKEOPTS, NINJAFLAGS, CARGO_BUILD_JOBS, LDFLAGS=-fuse-ld=mold, PORTAGE_TMPDIR=/var/tmp",
    "3. package.accept_keywords: amd64 (stable) | ~amd64 (testing) | ** (live/missing) | Scopes: All / =Exact / >=Forward",
    "4. package.mask & package.unmask: Block or unblock All (cat/pkg), Exact (=cat/pkg-v), or Forward (>=cat/pkg-v)",
    "5. User Patches (/etc/portage/patches/<cat>/<pkg>/): *.patch (enabled) <-> *.patch.disabled (disabled)",
)

def write_one(target: Path, line: str | None) -> None:
    comments = list(r for r in target.read_text(encoding="utf-8").splitlines() if r.strip().startswith("#")) if target.is_file() else list()
    if not line:
        if comments: target.write_text("\n".join(comments) + "\n", encoding="utf-8")
        elif target.is_file():
            target.unlink()
            try: target.parent.rmdir()
            except OSError: pass
        return
    target.parent.mkdir(parents=True, exist_ok=True); target.write_text("\n".join(comments + list((line,))) + "\n", encoding="utf-8")

class CfgStore:
    def __init__(self) -> None:
        self.state = collect_portage_state()
        self.pkg_map = {p.get("cp"): p for p in self.state.get("packages", ())}
        for p in self.state.get("packages", ()):
            p.update({
                "cur_flags": {f.get("flag"): f.get("effective") for f in p.get("flags", ())},
                "cur_envs": {e.get("name") for e in p.get("envs", ()) if e.get("initial")},
                "cur_kw": {"amd64": p.get("kw_s", False), "~amd64": p.get("kw_t", False), "**": p.get("kw_l", False)},
                "cur_kw_mode": p.get("kw_mode", "ALL"),
                "cur_mask": p.get("mask_mode", "NONE"),
                "cur_unmask": p.get("unmask_mode", "NONE"),
            })
            for pt in p.get("patches", ()): pt.update({"cur_en": pt.get("enabled")})

    def build_sanity_report(self) -> tuple[list[str], list[str]]:
        crit = {"sys-libs/glibc", "sys-devel/gcc", "sys-apps/portage", "sys-apps/systemd", "sys-apps/openrc", "dev-lang/python", "llvm-core/llvm", "dev-lang/rust"}
        changes, warnings = list(), list()
        for p in self.state.get("packages", ()):
            cp = p.get("cp")
            ou = {f.get("flag"): f.get("effective") for f in p.get("flags", ())}
            cu = p.get("cur_flags", {})
            if cu != ou:
                diffs = list(f"{'+' if cu.get(k) else '-'}{k}" for k in sorted(cu) if cu.get(k) != ou.get(k))
                changes.append(f"[package.use] {cp}: {' '.join(diffs)}")
                for f in p.get("flags", ()):
                    fl = f.get("flag")
                    if f.get("forced") and cu.get(fl) != ou.get(fl):
                        warnings.append(f"HIGH RISK: Profile-locked flag '{fl}' on {cp} ({f.get('force_reason')})")
            oe = {e.get("name") for e in p.get("envs", ()) if e.get("initial")}
            if p.get("cur_envs", set()) != oe:
                changes.append(f"[package.env] {cp}: {' '.join(sorted(p.get('cur_envs', set()))) or '(cleared)'}")
            okw = {"amd64": p.get("kw_s", False), "~amd64": p.get("kw_t", False), "**": p.get("kw_l", False)}
            ckw = p.get("cur_kw", {})
            if ckw != okw or (p.get("cur_kw_mode") != p.get("kw_mode") and any(ckw.values())):
                kws = list(k for k in ("amd64", "~amd64", "**") if ckw.get(k))
                changes.append(f"[package.accept_keywords] {cp} ({p.get('cur_kw_mode')}): {' '.join(kws) or '(cleared)'}")
                if ckw.get("**") and not okw.get("**"): warnings.append(f"BINHOST RISK: Adding '**' keyword to {cp}")
            if p.get("cur_mask") != p.get("mask_mode"):
                changes.append(f"[package.mask] {cp}: {p.get('mask_mode')} -> {p.get('cur_mask')}")
                if p.get("cur_mask") != "NONE" and cp in crit: warnings.append(f"CRITICAL RISK: Masking core package {cp}")
            if p.get("cur_unmask") != p.get("unmask_mode", "NONE"):
                changes.append(f"[package.unmask] {cp}: {p.get('unmask_mode', 'NONE')} -> {p.get('cur_unmask')}")
            for pt in p.get("patches", ()):
                if pt.get("cur_en") != pt.get("enabled"):
                    changes.append(f"[patches] {cp}/{pt.get('base_name')}: {'ENABLE' if pt.get('cur_en') else 'DISABLE'}")
        return changes, warnings

    def save_all(self) -> int:
        is_root = os.geteuid() == 0
        base = PORTAGE_DIR if is_root else (Path.cwd() / "portage-preview")
        changed = 0
        for p in self.state.get("packages", ()):
            cp, cat, name = p.get("cp"), p.get("cat"), p.get("name")
            if p.get("cur_flags") != {f.get("flag"): f.get("effective") for f in p.get("flags", ())}:
                changed += 1
                du = {f.get("flag"): p.get("cur_flags").get(f.get("flag")) for f in p.get("flags", ()) if p.get("cur_flags").get(f.get("flag")) != f.get("installed")}
                write_one(base / "package.use" / cat / name, f"{cp} {' '.join(f'{'' if du.get(k) else '-'}{k}' for k in sorted(du))}" if du else None)
            if p.get("cur_envs") != {e.get("name") for e in p.get("envs", ()) if e.get("initial")}:
                changed += 1; write_one(base / "package.env" / cat / name, f"{cp} {' '.join(sorted(p.get('cur_envs')))}" if p.get("cur_envs") else None)
            okw = {"amd64": p.get("kw_s", False), "~amd64": p.get("kw_t", False), "**": p.get("kw_l", False)}
            if p.get("cur_kw") != okw or (p.get("cur_kw_mode") != p.get("kw_mode") and any(p.get("cur_kw").values())):
                changed += 1; kws = list(k for k in ("amd64", "~amd64", "**") if p.get("cur_kw").get(k)); km = p.get("cur_kw_mode")
                ka = cp if km == "ALL" else ((p.get("kw_atom", f"={p.get('cpv')}") if p.get("kw_mode") == "EQ" else f"={p.get('cpv')}") if km == "EQ" else (p.get("kw_atom", f">={p.get('cpv')}") if p.get("kw_mode") == "FWD" else f">={p.get('cpv')}"))
                write_one(base / "package.accept_keywords" / cat / name, f"{ka} {' '.join(kws)}" if kws else None)
            if p.get("cur_mask") != p.get("mask_mode"):
                changed += 1; nm = p.get("cur_mask")
                write_one(base / "package.mask" / cat / name, None if nm == "NONE" else (cp if nm == "ALL" else (f"={p.get('cpv')}" if nm == "EQ" else f">={p.get('cpv')}")))
            if p.get("cur_unmask") != p.get("unmask_mode", "NONE"):
                changed += 1; num = p.get("cur_unmask")
                write_one(base / "package.unmask" / cat / name, None if num == "NONE" else (cp if num == "ALL" else (f"={p.get('cpv')}" if num == "EQ" else f">={p.get('cpv')}")))
            pdir = base / "patches" / cat / name
            for pt in p.get("patches", ()):
                if pt.get("cur_en") != pt.get("enabled"):
                    changed += 1; pdir.mkdir(parents=True, exist_ok=True)
                    if is_root and pt.get("path").is_file(): pt.get("path").rename(pdir / (pt.get("base_name") if pt.get("cur_en") else f"{pt.get('base_name')}.disabled"))
        return changed

class CursesTUI:
    def __init__(self, stdscr) -> None:
        self.scr = stdscr; curses.curs_set(0); self.scr.keypad(True)
        curses.start_color(); curses.use_default_colors()
        curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
        curses.init_pair(1, curses.COLOR_WHITE, curses.COLOR_BLUE)
        curses.init_pair(2, curses.COLOR_BLACK, curses.COLOR_CYAN)
        curses.init_pair(3, curses.COLOR_YELLOW, curses.COLOR_BLUE)
        curses.init_pair(4, curses.COLOR_RED, curses.COLOR_WHITE)
        self.scr.bkgd(" ", curses.color_pair(1))
        self.theme_idx = 0; self._load_theme_pref(); self.apply_theme()
        self.store = CfgStore(); self.focus = 0; self.tab = 0
        self.filter_txt = ""; self.sort_slow = False; self.expanded = set()
        self.tree_rows = list(); self.tree_idx = 0; self.tree_off = 0
        self.right_idx = 0; self.right_off = 0; self.cur_pkg = None
        self.env_file = ""; self.status = "Up/Down:Move  Left/Right:Tabs/Pane  Enter/Space:Select  /:Filter  t:Slowest  s:Save  q:Quit"
        self.rebuild_tree()

    def _theme_cfg_path(self) -> Path:
        return Path("/etc/minsktoocfg.theme") if os.geteuid() == 0 else (Path.home() / ".config" / "minsktoocfg" / "theme")

    def _load_theme_pref(self) -> None:
        tf = self._theme_cfg_path()
        if tf.is_file():
            name = tf.read_text(encoding="utf-8", errors="ignore").strip()
            if name in THEME_NAMES: self.theme_idx = THEME_NAMES.index(name)

    def apply_theme(self) -> None:
        name = THEME_NAMES.__getitem__(self.theme_idx)
        c = THEMES.get(name)
        curses.init_pair(1, c.__getitem__(0), c.__getitem__(1))
        curses.init_pair(2, c.__getitem__(2), c.__getitem__(3))
        curses.init_pair(3, c.__getitem__(4), c.__getitem__(5))
        curses.init_pair(4, c.__getitem__(6), c.__getitem__(7))
        self.scr.bkgd(" ", curses.color_pair(1))

    def _env_dir(self) -> Path:
        return ENV_PROFILES_DIR if os.geteuid() == 0 else (Path.cwd() / "portage-preview" / "env")

    def prompt_str(self, title: str, initial: str = "") -> str | None:
        h, w = self.scr.getmaxyx(); win = curses.newwin(5, max(44, w - 10), h // 2 - 2, 5)
        win.keypad(True); buf = list(initial); curses.curs_set(1)
        while True:
            win.erase(); win.box(); win.addnstr(1, 2, title, w - 14, curses.A_BOLD)
            win.addnstr(2, 2, "".join(buf), w - 14); win.refresh()
            ch = win.get_wch()
            if ch in ("\n", "\r", curses.KEY_ENTER): curses.curs_set(0); return "".join(buf)
            if ch == "\x1b": curses.curs_set(0); return None
            if ch in (curses.KEY_BACKSPACE, "\b", "\x7f"):
                if buf: buf.pop()
            elif isinstance(ch, str) and ch.isprintable(): buf.append(ch)

    def modal_confirm(self, title: str, lines: list[str], warn: bool = False) -> bool:
        h, w = self.scr.getmaxyx(); win = curses.newwin(h - 4, w - 6, 2, 3); win.keypad(True); off = 0
        while True:
            win.erase(); win.box(); attr = curses.color_pair(3) | curses.A_BOLD if warn else curses.A_BOLD
            win.addnstr(1, 2, title, w - 10, attr)
            for idx, ln in enumerate(lines[off:off + h - 8]):
                win.addnstr(3 + idx, 2, ln, w - 10, curses.color_pair(3) if ln.startswith(("HIGH", "BINHOST", "CRITICAL")) else 0)
            self._scrollbar(win, 3, w - 7, h - 9, len(lines), off)
            win.addnstr(h - 6, 2, "[y] Confirm   [n/Esc] Cancel   [Up/Down] Scroll", w - 10, curses.A_REVERSE); win.refresh()
            k = win.getch()
            if k in (ord("y"), ord("Y")): return True
            if k in (ord("n"), ord("N"), 27): return False
            if k == curses.KEY_DOWN and off + h - 8 < len(lines): off += 1
            elif k == curses.KEY_UP and off > 0: off -= 1

    def _badges(self, p: dict) -> str:
        b = list()
        if p.get("build_secs", 0) > 0: b.append(p.get("build_fmt"))
        if p.get("use_mod"): b.append("USE")
        if p.get("cur_envs"): b.append("ENV")
        if any(p.get("cur_kw", {}).values()): b.append("KW")
        if p.get("cur_mask", "NONE") != "NONE": b.append("MASK")
        if p.get("cur_unmask", "NONE") != "NONE": b.append("UNMASK")
        if p.get("has_patch"): b.append("PATCH")
        return " | ".join(b)

    def rebuild_tree(self) -> None:
        self.tree_rows.clear(); q = self.filter_txt.lower(); pkgs = self.store.state.get("packages", ())
        if self.sort_slow:
            slow = sorted((x for x in pkgs if x.get("build_secs", 0) > 0), key=lambda x: (-x.get("build_secs", 0), x.get("cp")))
            if slow:
                self.tree_rows.append(("CAT", "TOP_SLOW", f"[-] Top Slowest ({len(slow)})"))
                for p in slow:
                    bd = self._badges(p)
                    if not q or q in f"{p.get('cp')} {bd}".lower():
                        self.tree_rows.append(("PKG", p.get("cp"), f"  {p.get('name')} [{bd}]"))
        by_cat = {}
        for p in pkgs: by_cat.setdefault(p.get("cat"), list()).append(p)
        for cat in sorted(by_cat):
            matches = list(p for p in by_cat.get(cat, ()) if not q or q in f"{p.get('cp')} {self._badges(p)}".lower())
            if not matches: continue
            is_open = bool(q) or (cat in self.expanded)
            self.tree_rows.append(("CAT", cat, f"{'[-]' if is_open else '[+]'} {cat} ({len(matches)})"))
            if is_open:
                for p in matches:
                    bd = self._badges(p)
                    self.tree_rows.append(("PKG", p.get("cp"), f"  {p.get('name')}" + (f" [{bd}]" if bd else "")))
        if self.tree_rows:
            self.tree_idx = min(self.tree_idx, len(self.tree_rows) - 1)
            kind, val, _ = self.tree_rows[self.tree_idx]
            if kind == "PKG": self.cur_pkg = self.store.pkg_map.get(val)

    def _edit_conf_modal(self, fname: str) -> None:
        d = self._env_dir(); d.mkdir(parents=True, exist_ok=True)
        src = (d / fname) if (d / fname).is_file() else (ENV_PROFILES_DIR / fname)
        lines = src.read_text(encoding="utf-8", errors="ignore").splitlines() if src.is_file() else list(('MAKEOPTS="-j8 -l8"', 'NINJAFLAGS="-j8 -l8"', 'CARGO_BUILD_JOBS="8"'))
        while True:
            act = self.prompt_str(f"Edit {fname} (line# to edit, +add, r:rename, w:write, Esc:done)", "w")
            if act is None: return
            if act == "w":
                (d / fname).write_text("\n".join(lines) + "\n", encoding="utf-8")
                self.status = f"Saved {d / fname}"; return
            if act == "r":
                nn = self.prompt_str("New .conf filename:", fname)
                if nn and nn.strip():
                    fn2 = Path(nn.strip() if nn.strip().endswith(".conf") else f"{nn.strip()}.conf").name
                    (d / fname).unlink(missing_ok=True); fname = fn2
                    (d / fname).write_text("\n".join(lines) + "\n", encoding="utf-8")
            elif act == "+":
                nl = self.prompt_str("New line (e.g. MAKEOPTS=\"-j4\"):")
                if nl: lines.append(nl)
            elif act.isdigit() and 1 <= int(act) <= len(lines):
                idx = int(act) - 1
                nl = self.prompt_str(f"Line {act}:", lines[idx])
                if nl is not None: lines[idx] = nl

    def get_right_items(self) -> list[tuple]:
        p = self.cur_pkg
        if self.tab == 4: return list(("INFO", None, ln) for ln in INFO_LINES)
        if not p: return list((("INFO", None, "Select a package on the left to inspect and configure."),))
        out = list()
        if self.tab == 0:
            for f in p.get("flags", ()):
                fl = f.get("flag"); chk = "x" if p.get("cur_flags", {}).get(fl) else " "
                out.append(("USE", f, f"[{chk}] {fl}{' *' if f.get('forced') else ''}"))
        elif self.tab == 1:
            out.append(("ACT", "NEW_ENV", "[+] Create new /etc/portage/env/*.conf profile"))
            for e in p.get("envs", ()):
                en = e.get("name"); chk = "x" if en in p.get("cur_envs", set()) else " "
                out.append(("ENV", en, f"[{chk}] {en}  (Enter: View/Edit/Rename)"))
        elif self.tab == 2:
            for kw in ("amd64", "~amd64", "**"):
                out.append(("KW", kw, f"[{'x' if p.get('cur_kw', {}).get(kw) else ' '}] Keyword: {kw}"))
            for m, lbl in (("ALL", "All versions"), ("EQ", f"Exact (={p.get('cpv')})"), ("FWD", f"Forward (>={p.get('cpv')})")):
                out.append(("KWM", m, f"({'*' if p.get('cur_kw_mode') == m else ' '}) Scope: {lbl}"))
            for m, lbl in (("NONE", "Unmasked"), ("ALL", "Mask All"), ("EQ", "Mask Exact"), ("FWD", "Mask Forward")):
                out.append(("MSK", m, f"({'*' if p.get('cur_mask') == m else ' '}) {lbl}"))
            for m, lbl in (("NONE", "No local unmask"), ("ALL", "Unmask All"), ("EQ", "Unmask Exact"), ("FWD", "Unmask Forward")):
                out.append(("UMK", m, f"({'*' if p.get('cur_unmask') == m else ' '}) {lbl}"))
        elif self.tab == 3:
            for pt in p.get("patches", ()):
                out.append(("PAT", pt, f"[{'x' if pt.get('cur_en') else ' '}] {pt.get('base_name')}"))
            if not out: out.append(("INFO", None, f"No patches in /etc/portage/patches/{p.get('cp')}/"))
        return out

    def _scrollbar(self, win, y: int, x: int, bh: int, total: int, off: int, cur: int = -1) -> None:
        if total <= bh or bh < 2: return
        thumb_h = max(1, (bh * bh) // total)
        max_off = max(1, total - bh)
        thumb_y = y + min(bh - thumb_h, (off * (bh - thumb_h)) // max_off)
        for r in range(bh):
            ch = curses.ACS_BLOCK if (thumb_y <= y + r < thumb_y + thumb_h) else curses.ACS_CKBOARD
            win.addch(y + r, x, ch, curses.color_pair(3))
        pos = f"{(cur + 1) if cur >= 0 else (off + 1)}/{total}"
        win.addnstr(y + bh, max(1, x - len(pos) - 2), f" {pos} ", len(pos) + 2, curses.color_pair(3))

    def _box(self, y: int, x: int, h: int, w: int, title: str = "", active: bool = False) -> None:
        if h < 2 or w < 2: return
        attr = curses.color_pair(3) | curses.A_BOLD if active else curses.color_pair(1)
        self.scr.attron(attr)
        self.scr.hline(y, x + 1, curses.ACS_HLINE, w - 2); self.scr.hline(y + h - 1, x + 1, curses.ACS_HLINE, w - 2)
        self.scr.vline(y + 1, x, curses.ACS_VLINE, h - 2); self.scr.vline(y + 1, x + w - 1, curses.ACS_VLINE, h - 2)
        self.scr.addch(y, x, curses.ACS_ULCORNER); self.scr.addch(y, x + w - 1, curses.ACS_URCORNER)
        self.scr.addch(y + h - 1, x, curses.ACS_LLCORNER); self.scr.addch(y + h - 1, x + w - 1, curses.ACS_LRCORNER)
        if title: self.scr.addnstr(y, x + 2, f" {title} ", w - 4, attr)
        self.scr.attroff(attr)

    def pick_mc_theme(self) -> None:
        h, w = self.scr.getmaxyx(); mw, mh = 36, len(THEME_NAMES) + 5
        win = curses.newwin(mh, mw, max(1, h // 2 - mh // 2), max(1, w // 2 - mw // 2)); win.keypad(True)
        idx = self.theme_idx
        while True:
            win.erase(); win.bkgd(" ", curses.color_pair(2)); win.box()
            win.addnstr(0, 2, " Select MC Skin ", mw - 4, curses.A_BOLD)
            for i, nm in enumerate(THEME_NAMES):
                mark = "*" if i == self.theme_idx else " "
                win.addnstr(2 + i, 2, f" ({mark}) {nm} ".ljust(mw - 4), mw - 4, curses.color_pair(1) | curses.A_BOLD if i == idx else curses.color_pair(2))
            win.addnstr(mh - 2, 2, "Enter:Apply  Esc:Close", mw - 4); win.refresh()
            k = win.getch()
            if k == curses.KEY_DOWN: idx = (idx + 1) % len(THEME_NAMES)
            elif k == curses.KEY_UP: idx = (idx - 1) % len(THEME_NAMES)
            elif k == 27: return
            elif k in (10, 13, 32):
                self.theme_idx = idx; self.apply_theme()
                nm = THEME_NAMES.__getitem__(self.theme_idx)
                tf = self._theme_cfg_path(); tf.parent.mkdir(parents=True, exist_ok=True); tf.write_text(nm + chr(10), encoding="utf-8")
                self.status = f"MC Skin '{nm}' applied."; return

    def draw(self) -> None:
        self.scr.erase(); h, w = self.scr.getmaxyx(); mid = max(30, w // 3); bh = max(1, h - 6)
        tname = THEME_NAMES.__getitem__(self.theme_idx)
        mbar = f" Left   File   Options   Right   | Filter: {self.filter_txt or '(none)'}"
        rtag = f"[Skin: {tname}] "
        self.scr.addnstr(0, 0, mbar.ljust(max(1, w - len(rtag))), max(1, w - len(rtag)), curses.color_pair(2) | curses.A_BOLD)
        if w > len(rtag) + 4: self.scr.addnstr(0, w - len(rtag), rtag, len(rtag), curses.color_pair(2) | curses.A_BOLD)
        self._box(1, 0, bh + 2, mid, "Packages" if not self.sort_slow else "Packages (Slowest)", self.focus == 0)
        self._box(1, mid, bh + 2, w - mid, "", self.focus == 1)
        for i, name in enumerate(TABS):
            tx = mid + 2 + i * 13
            if tx + 11 < w: self.scr.addnstr(1, tx, f" {name} ", 12, curses.color_pair(2) | curses.A_BOLD if i == self.tab else curses.color_pair(1))
        for r in range(bh):
            idx = self.tree_off + r
            if idx < len(self.tree_rows):
                is_cur = (idx == self.tree_idx)
                attr = (curses.color_pair(2) | curses.A_BOLD) if (is_cur and self.focus == 0) else ((curses.color_pair(3) | curses.A_BOLD) if is_cur else curses.color_pair(1))
                self.scr.addnstr(2 + r, 2, self.tree_rows.__getitem__(idx).__getitem__(2).ljust(mid - 4), mid - 4, attr)
        items = self.get_right_items()
        for r in range(bh):
            idx = self.right_off + r
            if idx < len(items):
                sel = (self.focus == 1 and idx == self.right_idx)
                self.scr.addnstr(2 + r, mid + 2, items.__getitem__(idx).__getitem__(2).ljust(w - mid - 4), w - mid - 4, curses.color_pair(2) | curses.A_BOLD if sel else curses.color_pair(1))
        self._scrollbar(self.scr, 2, mid - 1, bh, len(self.tree_rows), self.tree_off, self.tree_idx)
        self._scrollbar(self.scr, 2, w - 1, bh, len(items), self.right_off, self.right_idx)
        stk = self.cur_pkg.get("use_stack", "") if self.cur_pkg else "Select a package"
        self.scr.addnstr(h - 3, 1, f"USE Stack: {stk}", w - 2, curses.color_pair(1))
        self.scr.addnstr(h - 2, 1, self.status, w - 2, curses.color_pair(3))
        fkeys = (("1", "Help"), ("2", "Save"), ("3", "Info"), ("4", "Edit"), ("5", "Rfrsh"), ("6", "Slow"), ("7", "Fltr"), ("8", "Patch"), ("9", "Skin"), ("10", "Quit"))
        fx = 0
        for num, lbl in fkeys:
            if fx + len(num) + len(lbl) + 1 >= w: break
            self.scr.addnstr(h - 1, fx, num, len(num), curses.color_pair(1) | curses.A_BOLD); fx += len(num)
            self.scr.addnstr(h - 1, fx, lbl.ljust(6), 6, curses.color_pair(2)); fx += 6
        self.scr.refresh()

    def run(self) -> None:
        while True:
            self.draw(); k = self.scr.getch(); items = self.get_right_items(); bh = max(1, self.scr.getmaxyx().__getitem__(0) - 6)
            if k in (ord("q"), ord("Q"), curses.KEY_F10): return
            if k == curses.KEY_F1: self.tab = 4; self.focus = 1; self.right_idx = self.right_off = 0
            elif k == curses.KEY_F2: curses.ungetch(ord("s"))
            elif k == curses.KEY_F3: self.tab = 4; self.focus = 1; self.right_idx = self.right_off = 0
            elif k == curses.KEY_F4: self.tab = 1; self.focus = 1; self.right_idx = self.right_off = 0
            elif k == curses.KEY_F5: curses.ungetch(ord("r"))
            elif k == curses.KEY_F6: curses.ungetch(ord("t"))
            elif k == curses.KEY_F7: curses.ungetch(ord("/"))
            elif k == curses.KEY_F8: self.tab = 3; self.focus = 1; self.right_idx = self.right_off = 0
            elif k in (curses.KEY_F9, ord("c"), ord("C")): self.pick_mc_theme()
            if k == curses.KEY_MOUSE:
                try: _, mx, my, _, bstate = curses.getmouse()
                except curses.error: continue
                h, w = self.scr.getmaxyx(); mid = max(30, w // 3); bh = max(1, h - 6)
                if bstate & curses.BUTTON4_PRESSED:
                    if mx < mid and self.tree_off > 0: self.tree_off -= 1
                    elif mx >= mid and self.right_off > 0: self.right_off -= 1
                elif bstate & getattr(curses, "BUTTON5_PRESSED", 2097152):
                    if mx < mid and self.tree_off + bh < len(self.tree_rows): self.tree_off += 1
                    elif mx >= mid and self.right_off + bh < len(items): self.right_off += 1
                elif bstate & (curses.BUTTON1_CLICKED | curses.BUTTON1_PRESSED | curses.BUTTON1_DOUBLE_CLICKED):
                    if my == 0: self.pick_mc_theme()
                    elif my == h - 1:
                        fk_map = (curses.KEY_F1, curses.KEY_F2, curses.KEY_F3, curses.KEY_F4, curses.KEY_F5, curses.KEY_F6, curses.KEY_F7, curses.KEY_F8, curses.KEY_F9, curses.KEY_F10)
                        fi = mx // 7
                        if 0 <= fi < len(fk_map): curses.ungetch(fk_map.__getitem__(fi))
                    elif my == 1 and mx > mid:
                        ti = (mx - mid - 2) // 13
                        if 0 <= ti < len(TABS): self.focus = 1; self.tab = ti; self.right_idx = self.right_off = 0
                    elif 2 <= my < 2 + bh and mx < mid:
                        idx = self.tree_off + (my - 2)
                        if idx < len(self.tree_rows):
                            self.focus = 0; self.tree_idx = idx
                            kd, vl, _ = self.tree_rows.__getitem__(idx)
                            if kd == "CAT" and vl != "TOP_SLOW": self.expanded.symmetric_difference_update((vl,)); self.rebuild_tree()
                            elif kd == "PKG": self.cur_pkg = self.store.pkg_map.get(vl)
                    elif 2 <= my < 2 + bh and mx > mid:
                        idx = self.right_off + (my - 2)
                        if idx < len(items):
                            self.focus = 1; self.right_idx = idx
                            curses.ungetch(32 if mx <= mid + 5 else 10)
                continue
            if k == 9: self.focus = 1 - self.focus
            elif k == curses.KEY_RIGHT:
                if self.focus == 0 and self.cur_pkg: self.focus = 1; self.right_idx = self.right_off = 0
                else: self.tab = (self.tab + 1) % len(TABS); self.right_idx = self.right_off = 0
            elif k == curses.KEY_LEFT:
                if self.focus == 1 and self.tab == 0: self.focus = 0
                elif self.focus == 1: self.tab = (self.tab - 1) % len(TABS); self.right_idx = self.right_off = 0
            elif ord("1") <= k <= ord("5"): self.tab = k - ord("1"); self.right_idx = self.right_off = 0
            elif k == ord("/"):
                q = self.prompt_str("Filter packages (blank to clear):", self.filter_txt)
                if q is not None: self.filter_txt = q.strip(); self.tree_idx = self.tree_off = 0; self.rebuild_tree()
            elif k == ord("t"): self.sort_slow = not self.sort_slow; self.tree_idx = self.tree_off = 0; self.rebuild_tree()
            elif k == ord("r"): self.store = CfgStore(); self.rebuild_tree(); self.status = "Reloaded Portage state."
            elif k == ord("s"):
                chg, wrn = self.store.build_sanity_report()
                if not chg: self.status = "No pending changes to save."; continue
                if self.modal_confirm("Pre-Save Sanity Check", (wrn + list(("",)) if wrn else list()) + chg, bool(wrn)):
                    n = self.store.save_all(); self.status = f"Saved {n} change(s)."
                    if os.geteuid() == 0 and self.modal_confirm("Run Emerge?", list(("Launch 'emerge -auDN @world' now?",))):
                        curses.endwin(); subprocess.run(("emerge", "-auDN", "@world"), check=False); return
            elif self.focus == 0:
                if k == curses.KEY_DOWN and self.tree_idx + 1 < len(self.tree_rows): self.tree_idx += 1
                elif k == curses.KEY_UP and self.tree_idx > 0: self.tree_idx -= 1
                elif k in (10, 13, 32) and self.tree_rows:
                    kd, vl, _ = self.tree_rows[self.tree_idx]
                    if kd == "CAT" and vl != "TOP_SLOW":
                        self.expanded.symmetric_difference_update((vl,)); self.rebuild_tree()
                    elif kd == "PKG":
                        self.cur_pkg = self.store.pkg_map.get(vl); self.focus = 1; self.right_idx = self.right_off = 0
                if self.tree_rows and self.tree_rows.__getitem__(self.tree_idx).__getitem__(0) == "PKG": self.cur_pkg = self.store.pkg_map.get(self.tree_rows.__getitem__(self.tree_idx).__getitem__(1))
                if self.tree_idx < self.tree_off: self.tree_off = self.tree_idx
                elif self.tree_idx >= self.tree_off + bh: self.tree_off = self.tree_idx - bh + 1
            elif self.focus == 1 and items:
                if k == curses.KEY_DOWN and self.right_idx + 1 < len(items): self.right_idx += 1
                elif k == curses.KEY_UP and self.right_idx > 0: self.right_idx -= 1
                elif k in (10, 13, 32) and self.cur_pkg:
                    kd, dt, _ = items[self.right_idx]
                    if kd == "ACT" and dt == "NEW_ENV":
                        fn = self.prompt_str("New .conf filename:")
                        if fn: self._edit_conf_modal(fn if fn.endswith(".conf") else f"{fn}.conf"); self.store = CfgStore(); self.rebuild_tree()
                    elif kd == "USE":
                        fl = dt.get("flag")
                        if not dt.get("forced") or self.modal_confirm("Profile-Locked Flag", list((f"'{fl}' is {dt.get('force_reason')}. Override anyway?",)), True):
                            self.cur_pkg.get("cur_flags").update({fl: not self.cur_pkg.get("cur_flags").get(fl)})
                    elif kd == "ENV":
                        if k == 32: self.cur_pkg.get("cur_envs").symmetric_difference_update((dt,))
                        else: self._edit_conf_modal(dt)
                    elif kd == "KW": self.cur_pkg.get("cur_kw").update({dt: not self.cur_pkg.get("cur_kw").get(dt)})
                    elif kd == "KWM": self.cur_pkg.update({"cur_kw_mode": dt})
                    elif kd == "MSK": self.cur_pkg.update({"cur_mask": dt})
                    elif kd == "UMK": self.cur_pkg.update({"cur_unmask": dt})
                    elif kd == "PAT": dt.update({"cur_en": not dt.get("cur_en")})
                    self.rebuild_tree()
                if self.right_idx < self.right_off: self.right_off = self.right_idx
                elif self.right_idx >= self.right_off + bh: self.right_off = self.right_idx - bh + 1

def main() -> None:
    try: ensure_gentoo_os(); curses.wrapper(lambda scr: CursesTUI(scr).run())
    except RuntimeError as exc: raise SystemExit(f"ERROR: {exc}")

if __name__ == "__main__": main()
